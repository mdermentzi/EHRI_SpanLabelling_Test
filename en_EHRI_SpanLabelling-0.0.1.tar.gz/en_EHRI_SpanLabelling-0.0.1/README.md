| Feature | Description |
| --- | --- |
| **Name** | `en_EHRI_SpanLabelling` |
| **Version** | `0.0.1` |
| **spaCy** | `>=3.4.1,<3.5.0` |
| **Default Pipeline** | `tok2vec`, `spancat`, `EHRI_Camps_Matcher`, `EHRI_Ghettos_Matcher`, `EHRI_Person_Matcher`, `EHRI_CB_Matcher`, `EHRI_Term_Matcher`, `EHRI_FUZZY_Camps_Matcher`, `EHRI_FUZZY_Person_Matcher`, `EHRI_FUZZY_Ghetto_Matcher`, `EHRI_FUZZY_CB_Matcher` |
| **Components** | `tok2vec`, `spancat`, `EHRI_Camps_Matcher`, `EHRI_Ghettos_Matcher`, `EHRI_Person_Matcher`, `EHRI_CB_Matcher`, `EHRI_Term_Matcher`, `EHRI_FUZZY_Camps_Matcher`, `EHRI_FUZZY_Person_Matcher`, `EHRI_FUZZY_Ghetto_Matcher`, `EHRI_FUZZY_CB_Matcher` |
| **Vectors** | 37796 keys, 37796 unique vectors (100 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [Maria Dermentzi](https://www.ehri-project.eu/) |

### Label Scheme

<details>

<summary>View label scheme (6 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`spancat`** | `DATE`, `PLACE`, `ORG`, `PERSON`, `CONC_CAMP`, `GHETTO` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `SPANS_SC_F` | 62.82 |
| `SPANS_SC_P` | 75.38 |
| `SPANS_SC_R` | 53.85 |
| `TOK2VEC_LOSS` | 817.89 |
| `SPANCAT_LOSS` | 152785.94 |