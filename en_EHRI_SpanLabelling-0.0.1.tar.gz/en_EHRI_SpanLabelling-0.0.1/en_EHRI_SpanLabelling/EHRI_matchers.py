from spacy.language import Language
from spacy.tokens import Span
from spaczz.matcher import FuzzyMatcher
from spacy.matcher import PhraseMatcher
from spacy.tokens import DocBin
from spacy.vocab import Vocab
from spacy.util import ensure_path


@Language.factory("EHRI_FUZZY_CB_Matcher")
class EHRI_FUZZY_CB_COMPONENT:
    def __init__(self, nlp, name: str = "EHRI_FUZZY_CB_Matcher"):
        self.vocab = nlp.vocab
        self.data = list()
        self.name = name

    def __call__(self, doc):
        # Apply the matcher to the doc
        matcher0 = FuzzyMatcher(self.vocab, flex=0, min_r1=90, min_r2=92, thresh=92, ignore_case=False)
        matcher0.add("APPROX_EHRI_CORPORATE_BODY", self.data)
        matches0 = matcher0(doc)
        spans0= [Span(doc, start, end, label="APPROX_EHRI_CORPORATE_BODY") for match_id, start, end, ratio in matches0]
        doc.spans['sc'].extend(list(spans0))
        return doc

    def add(self, data):
        # Add something to the component's data
        self.data.append(data)

    def from_disk(self, path, exclude=tuple()):  
        path = ensure_path(path)
        data_path = path / "CB_patterns_data.spacy"
        db = DocBin().from_disk(data_path)
        self.data = list(db.get_docs(self.vocab))
    
# Define the custom component
@Language.factory("EHRI_FUZZY_Camps_Matcher")
class EHRI_FUZZY_CAMPS_COMPONENT:
    def __init__(self, nlp, name: str = "EHRI_FUZZY_Camps_Matcher"):
        self.vocab = nlp.vocab
        self.data = list()
        self.name = name

    def __call__(self, doc):
        # Apply the matcher to the doc
        matcher1 = FuzzyMatcher(self.vocab, flex=0, min_r1=90, min_r2=92, thresh=92, ignore_case=False)
        matcher1.add("APPROX_EHRI_CAMP", self.data)
        matches1 = matcher1(doc)
        spans1 = [Span(doc, start, end, label="APPROX_EHRI_CAMP") for match_id, start, end, ratio in matches1]
        doc.spans['sc'].extend(list(spans1))
        return doc

    def add(self, data):
        # Add something to the component's data
        self.data.append(data)

    def from_disk(self, path, exclude=tuple()):  
        path = ensure_path(path)
        data_path = path / "camp_patterns_data.spacy"
        db = DocBin().from_disk(data_path)
        self.data = list(db.get_docs(self.vocab))

# Define the custom component
@Language.factory("EHRI_FUZZY_Person_Matcher")
class EHRI_FUZZY_PERSON_COMPONENT:
    def __init__(self, nlp, name: str = "EHRI_FUZZY_Person_Matcher"):
        self.vocab = nlp.vocab
        self.data = list()
        self.name = name

    def __call__(self, doc):
        # Apply the matcher to the doc
        matcher2 = FuzzyMatcher(self.vocab, flex=0, min_r1=90, min_r2=92, thresh=92, ignore_case=False)
        matcher2.add("APPROX_EHRI_PERSONALITY", self.data)
        matches2 = matcher2(doc)
        spans2 = [Span(doc, start, end, label="APPROX_EHRI_PERSONALITY") for match_id, start, end, ratio in matches2]
        doc.spans['sc'].extend(list(spans2))
        return doc

    def add(self, data):
        # Add something to the component's data
        self.data.append(data)

    def from_disk(self, path, exclude=tuple()):  
        path = ensure_path(path)
        data_path = path / "person_patterns_data.spacy"
        db = DocBin().from_disk(data_path)
        self.data = list(db.get_docs(self.vocab))

# Define the custom component
@Language.factory("EHRI_FUZZY_Ghetto_Matcher")
class EHRI_FUZZY_GHETTO_COMPONENT:
    def __init__(self, nlp, name: str = "EHRI_FUZZY_Ghetto_Matcher"):
        self.vocab = nlp.vocab
        self.data = list()
        self.name = name

    def __call__(self, doc):
        # Apply the matcher to the doc
        matcher3 = FuzzyMatcher(self.vocab, flex=0, min_r1=90, min_r2=92, thresh=92, ignore_case=False)
        matcher3.add("APPROX_EHRI_GHETTO", self.data)
        matches3 = matcher3(doc)
        spans3 = [Span(doc, start, end, label="APPROX_EHRI_GHETTO") for match_id, start, end, ratio in matches3]
        doc.spans['sc'].extend(list(spans3))
        return doc

    def add(self, data):
        # Add something to the component's data
        self.data.append(data)

    def from_disk(self, path, exclude=tuple()):  
        path = ensure_path(path)
        data_path = path / "ghetto_patterns_data.spacy"
        db = DocBin().from_disk(data_path)
        self.data = list(db.get_docs(self.vocab))

# Define the custom component
@Language.factory("EHRI_Camps_Matcher")
class EHRI_CAMPS_COMPONENT:
    def __init__(self, nlp, name: str = "EHRI_Camps_Matcher"):
        self.vocab = nlp.vocab
        self.data = list()
        self.name = name

    def __call__(self, doc):
        # Apply the matcher to the doc
        matcher4 = PhraseMatcher(self.vocab)
        matcher4.add("EHRI_CAMP", self.data)
        matches4 = matcher4(doc)
        spans4 = [Span(doc, start, end, label="EHRI_CAMP") for match_id, start, end in matches4]
        doc.spans['sc'].extend(list(spans4))
        return doc

    def add(self, data):
        # Add something to the component's data
        self.data.append(data)

    def from_disk(self, path, exclude=tuple()):  
        path = ensure_path(path)
        data_path = path / "camp_patterns_data.spacy"
        db = DocBin().from_disk(data_path)
        self.data = list(db.get_docs(self.vocab))

# Define the custom component
@Language.factory("EHRI_Ghettos_Matcher")
class EHRI_GHETTO_COMPONENT:
    def __init__(self, nlp, name: str = "EHRI_Ghettos_Matcher"):
        self.vocab = nlp.vocab
        self.data = list()
        self.name = name

    def __call__(self, doc):
        # Apply the matcher to the doc
        matcher5 = PhraseMatcher(self.vocab)
        matcher5.add("EHRI_GHETTO", self.data)
        matches5 = matcher5(doc)
        spans5 = [Span(doc, start, end, label="EHRI_GHETTO") for match_id, start, end in matches5]
        doc.spans['sc'].extend(list(spans5))
        return doc

    def add(self, data):
        # Add something to the component's data
        self.data.append(data)

    def from_disk(self, path, exclude=tuple()):  
        path = ensure_path(path)
        data_path = path / "ghetto_patterns_data.spacy"
        db = DocBin().from_disk(data_path)
        self.data = list(db.get_docs(self.vocab))


# Define the custom component
@Language.factory("EHRI_Person_Matcher")
class EHRI_PERSON_COMPONENT:
    def __init__(self, nlp, name: str = "EHRI_Person_Matcher"):
        self.vocab = nlp.vocab
        self.data = list()
        self.name = name

    def __call__(self, doc):
        # Apply the matcher to the doc
        matcher6 = PhraseMatcher(self.vocab)
        matcher6.add("EHRI_PERSONALITY", self.data)
        matches6 = matcher6(doc)
        spans6 = [Span(doc, start, end, label="EHRI_PERSONALITY") for match_id, start, end in matches6]
        doc.spans['sc'].extend(list(spans6))
        return doc

    def add(self, data):
        # Add something to the component's data
        self.data.append(data)

    def from_disk(self, path, exclude=tuple()):  
        path = ensure_path(path)
        data_path = path / "person_patterns_data.spacy"
        db = DocBin().from_disk(data_path)
        self.data = list(db.get_docs(self.vocab))



# Define the custom component
@Language.factory("EHRI_CB_Matcher")
class EHRI_CB_COMPONENT:
    def __init__(self, nlp, name: str = "EHRI_CB_Matcher"):
        self.vocab = nlp.vocab
        self.data = list()
        self.name = name

    def __call__(self, doc):
        # Apply the matcher to the doc
        matcher7 = PhraseMatcher(self.vocab)
        matcher7.add("EHRI_CORPORATE_BODY", self.data)
        matches7 = matcher7(doc)
        spans7 = [Span(doc, start, end, label="EHRI_CORPORATE_BODY") for match_id, start, end in matches7]
        doc.spans['sc'].extend(list(spans7))
        return doc

    def add(self, data):
        # Add something to the component's data
        self.data.append(data)
    
    def from_disk(self, path, exclude=tuple()):  
        path = ensure_path(path)
        data_path = path / "CB_patterns_data.spacy"
        db = DocBin().from_disk(data_path)
        self.data = list(db.get_docs(self.vocab))


# Define the custom component
@Language.factory("EHRI_Term_Matcher")
class CustomComponent:
    def __init__(self, nlp, name: str = "EHRI_Term_Matcher"):
        self.vocab = nlp.vocab
        self.data = list()
        self.name = name

    def __call__(self, doc):
        # Apply the matcher to the doc
        matcher8 = PhraseMatcher(self.vocab)
        matcher8.add("EHRI_TERM", self.data)
        matches8 = matcher8(doc)
        spans8= [Span(doc, start, end, label="EHRI_TERM") for match_id, start, end in matches8]
        doc.spans['sc'].extend(list(spans8))
        return doc

    def add(self, data):
        # Add something to the component's data
        self.data.append(data)

    def from_disk(self, path, exclude=tuple()):  
        path = ensure_path(path)
        data_path = path / "term_patterns_data.spacy"
        db = DocBin().from_disk(data_path)
        self.data = list(db.get_docs(self.vocab))
